import 'package:flutter/material.dart';

class VagaCadastro extends StatefulWidget {
  @override
  _VagaCadastroState createState() => _VagaCadastroState();
}

InputDecoration _customInputDecoration(String labelText) {
  return InputDecoration(
    labelText: labelText,
    labelStyle: TextStyle(fontSize: 16), //Tamanho da fonte dos campos
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(10.0), //Borda arredondada
    ),
    enabledBorder: OutlineInputBorder(
      borderSide: BorderSide(color: Colors.grey), //Cor da borda quando inativo
      borderRadius: BorderRadius.circular(10.0),
    ),
    focusedBorder: OutlineInputBorder(
      borderSide:
          BorderSide(color: Color(0xff761290)), //Cor da borda quando ativo
      borderRadius: BorderRadius.circular(10.0),
    ),
  );
}

class _VagaCadastroState extends State<VagaCadastro> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Cadastro de vagas =D'),
      ),
      body: CustomScrollView(
        //Permite rolagem da página
        slivers: <Widget>[
          SliverList(
            delegate: SliverChildListDelegate(
              [
                SizedBox(height: 10),
                Center(
                  child: Padding(
                    padding: const EdgeInsets.all(20.0),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        //Campo "Nome do responsável no local"
                        TextFormField(
                          decoration: _customInputDecoration(
                              'Endereço completo da vaga:'),
                        ),

                        SizedBox(height: 30),

                        TextFormField(
                          decoration: _customInputDecoration(
                              'Tipo da vaga (Ex.: preferencial):'),
                        ),

                        SizedBox(height: 30),

                        TextFormField(
                          decoration: _customInputDecoration('Status:'),
                        ),

                        SizedBox(height: 30),

                        TextFormField(
                          decoration: _customInputDecoration(
                              'URL da Sinalização (Placa):'),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      //bottomNavigationBar: MenuInferior(),
    );
  }
}
