import 'package:crud_projeto_final/components/vaga_tile.dart';
import 'package:flutter/material.dart';

import '../data/dummy_vagas.dart';

class VagaList extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    //const vagas = {...DUMMY_VAGAS};
    final vagas = {...DUMMY_VAGAS};

    return Scaffold(
      appBar: AppBar(
        title: Text('Vagas de Estacionamento'),
        actions: <Widget>[IconButton(onPressed: () {}, icon: Icon(Icons.add))],
      ),
      body: ListView.builder(
        itemCount: vagas.length,
        //itemBuilder: (ctx, i) => Text(vagas.values.elementAt(i).endereco),
        itemBuilder: (ctx, i) => VagaTile(vagas.values.elementAt(i)),
      ),
    );
  }
}
