import 'package:flutter/material.dart';

class Vaga {
  final String id;
  final String endereco;
  final String tipoVaga;
  final String status;
  final String iconTipoVaga;

  const Vaga({
    required this.id,
    required this.endereco,
    required this.tipoVaga,
    required this.status,
    required this.iconTipoVaga,
  });
}
