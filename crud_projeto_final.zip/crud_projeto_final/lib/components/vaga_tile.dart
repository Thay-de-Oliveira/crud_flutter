import 'package:flutter/material.dart';

import '../models/vaga_model.dart';

class VagaTile extends StatelessWidget {
  final Vaga vaga;

  const VagaTile(this.vaga);

  @override
  Widget build(BuildContext context) {
    final icon = vaga.iconTipoVaga == null || vaga.iconTipoVaga.isEmpty
        ? CircleAvatar(child: Icon(Icons.person))
        : CircleAvatar(backgroundImage: NetworkImage(vaga.iconTipoVaga));
    return Padding(
      padding: EdgeInsets.only(right: 1),
      child: ListTile(
        leading: icon,
        title: Text(vaga.status),
        subtitle: Text(vaga.endereco),
        trailing: Container(
          width: 80,
          child: Row(
            children: <Widget>[
              IconButton(
                onPressed: () {},
                icon: Icon(Icons.edit),
                color: Color(0xffe596e5),
              ),
              IconButton(
                onPressed: () {},
                icon: Icon(Icons.delete),
                color: Color(0xffae1e83),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
