import 'package:flutter/material.dart';

class MenuInferior extends StatefulWidget {
  @override
  _MenuInferiorState createState() => _MenuInferiorState();
}

class _MenuInferiorState extends State<MenuInferior> {
  String telaAtual = 'inicio'; // Inicialmente, a tela de início está ativa

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 360,
      height: 72,
      child: Stack(
        children: [
          Positioned(
            left: 0,
            top: 0,
            child: Container(
              width: 360,
              height: 72,
              decoration: BoxDecoration(color: Colors.white),
            ),
          ),
          Positioned(
            left: 50,
            top: 26,
            child: GestureDetector(
              onTap: () {
                setState(() {
                  telaAtual = 'cadastro';
                });
                Navigator.of(context).pushNamed('/vaga_forms_view');
              },
              child: Container(
                width: 95,
                height: 20,
                child: Stack(
                  children: [
                    Positioned(
                      left: 28,
                      top: 0,
                      child: Text(
                        'Cadastro',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: telaAtual == 'cadastro'
                              ? Colors.white
                              : Color(0xff999999),
                          fontSize: 17,
                          fontFamily: 'Roboto',
                          fontWeight: FontWeight.w500,
                          height: 0,
                          letterSpacing: -0.30,
                        ),
                      ),
                    ),
                    Positioned(
                      left: 0,
                      top: 0,
                      child: Container(
                        width: 20,
                        height: 20,
                        child: Stack(
                          children: [
                            // Coloque a lógica da imagem ativa/inativa aqui
                            Image.asset(
                              telaAtual == 'cadastro'
                                  ? 'assets/imagens/icon-add_ativo'
                                  : 'assets/imagens/icon-add_normal.png',
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Positioned(
            left: 235,
            top: 26,
            child: GestureDetector(
              onTap: () {
                setState(() {
                  telaAtual = 'lista';
                });
                Navigator.of(context).pushNamed('/vaga_list_view');
              },
              child: Container(
                width: 64,
                height: 20,
                child: Stack(
                  children: [
                    Positioned(
                      left: 28,
                      top: 0,
                      child: Text(
                        'Início',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: telaAtual == 'inicio'
                              ? Colors.white
                              : Color(0xff63127e),
                          fontSize: 17,
                          fontFamily: 'Roboto',
                          fontWeight: FontWeight.w400,
                          height: 0,
                          letterSpacing: -0.30,
                        ),
                      ),
                    ),
                    Positioned(
                      left: 0,
                      top: 0,
                      child: Container(
                        width: 20,
                        height: 20,
                        child: Stack(
                          children: [
                            // Coloque a lógica da imagem ativa/inativa aqui
                            Image.asset(
                              telaAtual == 'inicio'
                                  ? 'assets/imagens/icon-list_ativo.png'
                                  : 'assets/imagens/icon-list_normal.png',
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
