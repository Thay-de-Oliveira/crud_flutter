import '../models/vaga_model.dart';

const DUMMY_VAGAS = {
  '1': const Vaga(
    id: '1',
    endereco: 'R. Condá, 123E - Centro',
    tipoVaga: 'Normal',
    status: 'Disponivel',
    iconTipoVaga:
        'https://www.seton.com.br/media/catalog/product/cache/1/image/9df78eab33525d08d6e5fb8d27136e95/c/0/c0260.jpg',
  ),
  '2': const Vaga(
    id: '2',
    endereco: 'Av. São Pedro, 456D - Efapi',
    tipoVaga: 'Preferencial',
    status: 'Disponivel',
    iconTipoVaga:
        'https://guiaderodas.com/wp-content/uploads/2020/11/Si%CC%81mbolo-Internacional-de-Acesso-SIA.jpg',
  ),
  '3': const Vaga(
    id: '3',
    endereco: 'Av. Fernando Machado, 789E - Centro',
    tipoVaga: 'Normal',
    status: 'Ocupada',
    iconTipoVaga:
        'https://www.seton.com.br/media/catalog/product/cache/1/image/9df78eab33525d08d6e5fb8d27136e95/c/0/c0260.jpg',
  ),
  '4': const Vaga(
    id: '4',
    endereco: 'R. Severino Bernardi, 222E - Efapi',
    tipoVaga: 'Preferencial',
    status: 'Disponivel',
    iconTipoVaga:
        'https://guiaderodas.com/wp-content/uploads/2020/11/Si%CC%81mbolo-Internacional-de-Acesso-SIA.jpg',
  ),
};
