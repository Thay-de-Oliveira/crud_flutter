import 'package:crud_projeto_final/view/vaga_forms_view.dart';
import 'package:crud_projeto_final/view/vaga_list_view.dart';
import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Vagas de estacionamento online =)',
      theme: ThemeData(
        primarySwatch: Colors.purple,
      ),
      initialRoute: '/', //Rota inicial
      routes: {
        '/': (context) => VagaCadastro(), //Login
        '/vaga_list_view': (context) => VagaList(),
      },
      //home: VagaList(),
      //home: VagaCadastro(),
    );
  }
}
