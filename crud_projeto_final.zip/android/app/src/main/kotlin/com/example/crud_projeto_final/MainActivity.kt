package com.example.crud_projeto_final

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
